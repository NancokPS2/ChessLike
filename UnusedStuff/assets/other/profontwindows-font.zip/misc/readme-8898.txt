This is a modified Version of ProFont for Macintosh,
bitmap version, based on ProFont Distribution 2.2.
I've simply added a Euro character which looks quite ugly
at some sizes and isn't available at all at 7pt size.

To get the full original Distribution, other ProFont builds
and more information
go to <http://tobiasjung.name/profont/>


DISCLAIMER
See LICENSE file


Tobias Jung
January 2014
profont@tobiasjung.name
